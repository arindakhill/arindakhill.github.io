let books = [
    {   "id":"1",
        "title":"the Street Lawyer",
        "ISBN":12244546,
        "publishedDate":"2023-12-24",
        "author":"John Grisham"
    },
    {
        "id":"2",   
        "title":"HarryPotter",
        "ISBN":123546,
        "publishedDate":"2010-12-30",
        "author":"Boo ya"
    },
    {
        "id":"3",
        "title":"Far from HOme",
        "ISBN":447568,
        "publishedDate":"2020-11-11",
        "author":"Christopher Nolan"
    }




];

module.exports = class Book {

    constructor(id, title, ISBN, publishedDate, author) {
        this.id = id;
        this.title = title;
        this.ISBN = ISBN;
        this.publishedDate = publishedDate;
        this.author = author;
    }

    save() {
        this.id = Math.random().toString();
        books.push(this);
        console.log(this);
        return this;
    }

    update() {
        const index = books.findIndex(p => p.id == this.id);
        if (index > -1) {
            books.splice(index, 1, this);
            return this;
        } else {
            throw new Error('NOT Found');
        }

    }

    static fetchAll() {
        return books;
    }

    static findById(bookId) {
        const index = books.findIndex(p => p.id === bookId);
        if (index > -1) {
            return books[index];
        } else {
            throw new Error('NOT Found');
        }
    }

    static deleteById(bookId) {
        const index = books.findIndex(p => p.id == bookId);
        if (index > -1) {
            books = books.filter(p => p.id != bookId);
        } else {
            throw new Error('NOT Found');
        }
    }

}